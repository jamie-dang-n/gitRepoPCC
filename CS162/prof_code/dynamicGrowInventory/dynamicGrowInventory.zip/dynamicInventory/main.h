/* inventory main function header file
 * CS162, Su 2023
 * Robert Martin*/

#ifndef main_h
#define main_h

int validInt();
double validDouble();
char getMenuChoice();

#endif
