/* main function header file
 * CS162 Summer 2023 assessment files */

#ifndef MAIN_H
#define MAIN_H

#include "carLot.h"
#include <iostream>

#endif
