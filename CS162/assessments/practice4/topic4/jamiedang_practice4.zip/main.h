#pragma once
#include <iostream>
using namespace std;
#include <cstring>
#include <fstream>
#include <iomanip>
#include <limits>
#include "date.h"
#include "item.h"
#include "itemList.h"

int main(int argc, char ** argv);
void getDate(int&, int&, int&);

